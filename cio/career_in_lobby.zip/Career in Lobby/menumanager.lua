custom_career_button = custom_career_button or {}
custom_career_button.menu_id = "custom_career_button_menu_id"

Hooks:AddHook("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_CareerInLobbyMenu", function(menu_manager, nodes)
	MenuHelper:NewMenu(custom_career_button.menu_id)
end)

Hooks:AddHook("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_CareerInLobbyMenu", function(menu_manager, nodes)
	MenuCallbackHandler.open_story_missions = function(self, item)
		managers.menu:open_node("story_missions")
	end
	
	MenuHelper:AddButton({
		id = "open_story_missions",
		title = "menu_story_missions",
		desc = nil,
		callback = "open_story_missions",
		menu_id = custom_career_button.menu_id,
	})
end)

Hooks:AddHook("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_CareerInLobbyMenu", function(menu_manager, nodes)
	nodes[custom_career_button.menu_id] = MenuHelper:BuildMenu(custom_career_button.menu_id)
	MenuHelper:AddMenuItem(nodes.lobby, custom_career_button.menu_id, "menu_story_missions", "menu_story_missions_help", "inventory", "before")
end)