sniper_alert = sniper_alert or {}
sniper_alert._path = ModPath
sniper_alert.settings_path = SavePath .. "sa_settings.txt"
sniper_alert.get_alpha = true
sniper_alert.alpha = 0
sniper_alert.color_char = {
	f = true,
	e = true,
	d = true,
	c = true,
	b = true,
	a = true,
}
for i = 0, 9 do
	sniper_alert.color_char[tostring(9 - i)] = true
end
sniper_alert.settings = {}
sniper_alert.default = {
	enable_mod = true,
	show_hint = true,
	hint_time = "3",
	hint_text = "SNIPER ALERT",
	show_effect = true,
	effect_in = true,
	speed_in = "5",
	effect_out = true,
	speed_out = "5",
	effect_time = "1",
	effect_color = "ffdd00",
	effect_type = 1
}
sniper_alert.update = false

function sniper_alert:update(item, items_table, value)
	if type(items_table) ~= "table" then
		local s = tostring(items_table)
		items_table = {}
		items_table[s] = true
	end

	local node_items = item._parameters.gui_node.row_items
	for k, v in pairs(node_items) do
		if items_table[v.item._parameters.name] and v.item.set_value then
			local item_type = v.item._type

			if item_type == "toggle" then
				v.item:set_value(value and "on" or "off")
			else
				v.item:set_value(value)
			end
		end
	end

	managers.viewport:resolution_changed()
end

function sniper_alert:set(item, setting, value)
	sniper_alert.settings[setting] = value
	local datatype = type(value)
	local _type
	if datatype == "boolean" then
		_type = "_toggle"
	elseif datatype == "string" then
		_type = "_input"
	elseif datatype == "number" then
		_type = "_mutli"
	else
		_type = "_nil"
	end
	sniper_alert:update(item, setting .. _type, value)
end

function sniper_alert:reset(item)
	for k, v in pairs(sniper_alert.default) do
		sniper_alert:set(item, k, v)
	end
end

function sniper_alert:save()
	local file = io.open(sniper_alert.settings_path, "w+")
	if file then
		file:write(json.encode(sniper_alert.settings))
		file:close()
	end
	sniper_alert.update = true
end

function sniper_alert:load()
	local file = io.open(sniper_alert.settings_path, "r")
	if file then
		for k, v in pairs(json.decode(file:read('*all')) or {}) do
			sniper_alert.settings[k] = v
		end
		file:close()
	end
	for k, v in pairs(sniper_alert.default) do
		if not sniper_alert.settings[k] then
			sniper_alert.settings[k] = v
		end
	end
	log("[SA] Successfully loaded settings")
end
sniper_alert:load()

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_sniper_alert", function(loc)
	loc:load_localization_file(sniper_alert._path .. "assets/menu/english.json", false)
end)

Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_sniper_alert", function(menu_manager)
	-- save settings
	MenuCallbackHandler.saChangedFocus = function(self, focus)
		if not focus then
			sniper_alert:save()
		end
	end
	
	-- mod callback
	MenuCallbackHandler.callback_enable_mod = function(self, item)
		sniper_alert.settings.enable_mod = item:value() == "on"
	end
	
	-- hint callbacks
	MenuCallbackHandler.callback_show_hint = function(self, item)
		sniper_alert.settings.show_hint = item:value() == "on"
	end
	
	MenuCallbackHandler.callback_hint_time = function(self, item)
		local value = tonumber(item:value())
		if value and value >= 0 then
			value = tostring(value)
		else
			value = sniper_alert.settings.hint_time
		end
		sniper_alert:set(item, "hint_time", value)
	end
	
	MenuCallbackHandler.callback_hint_text = function(self, item)
		sniper_alert:set(item, "hint_text", string.upper(item:value()))
	end
	
	-- effect callbacks
	MenuCallbackHandler.callback_show_effect = function(self, item)
		sniper_alert.settings.show_effect = item:value() == "on"
	end
	
	
	MenuCallbackHandler.callback_effect_in = function(self, item)
		sniper_alert.settings.effect_in = item:value() == "on"
	end
	
	MenuCallbackHandler.callback_speed_in = function(self, item)
		local value = tonumber(item:value())
		if value and value > 0 then
			value = tostring(value)
		else
			value = sniper_alert.settings.speed_in
		end
		sniper_alert:set(item, "speed_in", value)
	end
	
	MenuCallbackHandler.callback_effect_out = function(self, item)
		sniper_alert.settings.effect_out = item:value() == "on"
	end
	
	MenuCallbackHandler.callback_speed_out = function(self, item)
		local value = tonumber(item:value())
		if value and value > 0 then
			value = tostring(value)
		else
			value = sniper_alert.settings.speed_out
		end
		sniper_alert:set(item, "speed_out", value)
	end
	
	MenuCallbackHandler.callback_effect_time = function(self, item)
		local value = tonumber(item:value())
		if value and value >= 0 then
			value = tostring(value)
		else
			value = sniper_alert.settings.effect_time
		end
		sniper_alert:set(item, "effect_time", value)
	end
	
	MenuCallbackHandler.callback_effect_color = function(self, item)
		local color_length = string.len(item:value())
		local value = ""
		if color_length == 6 or color_length == 3 or color_length == 8 or color_length == 4 then
			local item_value = string.lower(item:value())
			for i = 1, color_length do
				local character = string.sub(item_value, i, i)
				if not sniper_alert.color_char[character] then
					value = sniper_alert.settings.effect_color
					break
				end
				if color_length == 3 or color_length == 4 then
					value = value .. character
				end
				value = value .. character
			end
		else
			value = sniper_alert.settings.effect_color
		end
		sniper_alert:set(item, "effect_color", value)
	end
	
	MenuCallbackHandler.callback_effect_type = function(self, item)
		sniper_alert.settings.effect_type = item:value()
	end
	
	-- nuclear option
	MenuCallbackHandler.callback_reset_sa = function(self, item)
		local dialog_data = {
			title = "Warning",
			text = "Are you sure you want to reset all settings?"
		}
		local yes_button = {
			text = "Yes",
			callback_func = callback(self, sniper_alert, "reset", item)
		}
		local no_button = {
			text = "No",
			cancel_button = true
		}
		dialog_data.button_list = {
			yes_button,
			no_button
		}
		
		managers.system_menu:show(dialog_data)
	end
	
	MenuHelper:LoadFromJsonFile(sniper_alert._path .. "assets/menu/main.json", sniper_alert, sniper_alert.settings)
end )