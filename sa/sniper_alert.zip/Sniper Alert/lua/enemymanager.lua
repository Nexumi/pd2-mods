Hooks:PostHook(EnemyManager, "on_enemy_registered", "detect_sniper", function(self, __unit)
	if sniper_alert.settings.enable_mod and __unit:base()._tweak_table == "sniper" then
		if sniper_alert.settings.show_hint then
			managers.hud:show_hint({time = tonumber(sniper_alert.settings.hint_time), text = sniper_alert.settings.hint_text})
		end
		
		if sniper_alert.settings.show_effect then
			local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
			local sniper_alert_hud_panel = hud.panel:child("Sniper_Alert_hud_panel")
			if not sniper_alert_hud_panel then
				local _type
				if sniper_alert.settings.effect_type == 1 then
					_type = "_light"
				else
					_type = "_dark"
				end
				sniper_alert_hud_panel = hud.panel:bitmap({
					name = "Sniper_Alert_hud_panel",
					visible = false,
					texture = "assets/textures/sniper_alert_effect" .. _type,
					layer = 0,
					color = Color(sniper_alert.settings.effect_color),
					blend_mode = "disable",
					w = hud.panel:w(),
					h = hud.panel:h(),
					x = 0,
					y = 0
				})
			end
			
			if sniper_alert.update then
				sniper_alert_hud_panel:set_color(Color(sniper_alert.settings.effect_color))
				sniper_alert.update = false
			end
			
			local function anim(o)
				-- get alpha
				local a = sniper_alert.true_alpha or sniper_alert_hud_panel:color().a
				
				if sniper_alert.get_alpha then
					sniper_alert.true_alpha = a
					sniper_alert.get_alpha = false
				end
				
				-- fade in				
				sniper_alert_hud_panel:set_visible(true)
				
				if sniper_alert.settings.effect_in then
					local t = sniper_alert.alpha
					while t < a do
						t = t + coroutine.yield() * tonumber(sniper_alert.settings.speed_in)
						sniper_alert_hud_panel:set_alpha(t)
						sniper_alert.alpha = t
					end
				end
				
				-- wait
				if sniper_alert.alpha ~= a then
					sniper_alert_hud_panel:set_alpha(a)
					sniper_alert.alpha = a
				end
				over(tonumber(sniper_alert.settings.effect_time), function() end)
				
				-- fade out
				if sniper_alert.settings.effect_out then
					local t = sniper_alert.alpha
					while t > 0 do
						t = t - coroutine.yield() * tonumber(sniper_alert.settings.speed_out)
						sniper_alert_hud_panel:set_alpha(t)
						sniper_alert.alpha = t
					end
				end
				
				sniper_alert_hud_panel:set_alpha(0)
				sniper_alert.alpha = 0
				sniper_alert_hud_panel:stop()
				sniper_alert_hud_panel:set_visible(false)
			end
			sniper_alert_hud_panel:stop()
			sniper_alert_hud_panel:animate(hud.flash_icon, tonumber(sniper_alert.settings.effect_time))
			sniper_alert_hud_panel:animate(anim)
		end
	end
end)

for _, file in pairs(file.GetFiles(sniper_alert._path.. "assets/textures/")) do
	DB:create_entry(Idstring("texture"), Idstring("assets/textures/".. string.gsub(file, ".texture", "")), sniper_alert._path.. "assets/textures/".. file)
end

log("[SA] Successfully loaded hook")